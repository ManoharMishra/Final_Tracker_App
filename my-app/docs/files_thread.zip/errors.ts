// lib/errors.ts

export type ErrorCode =
  | "VALIDATION_ERROR"
  | "NOT_FOUND"
  | "FORBIDDEN"
  | "CONFLICT"
  | "INTERNAL_ERROR";

export class ApiError extends Error {
  public readonly code: ErrorCode;
  public readonly statusCode: number;
  public readonly details: unknown[];

  constructor(code: ErrorCode, message: string, details: unknown[] = []) {
    super(message);
    this.code = code;
    this.details = details;
    this.name = "ApiError";

    switch (code) {
      case "VALIDATION_ERROR":
        this.statusCode = 400;
        break;
      case "FORBIDDEN":
        this.statusCode = 403;
        break;
      case "NOT_FOUND":
        this.statusCode = 404;
        break;
      case "CONFLICT":
        this.statusCode = 409;
        break;
      default:
        this.statusCode = 500;
    }
  }

  toJSON() {
    return {
      error: {
        code: this.code,
        message: this.message,
        details: this.details,
      },
    };
  }
}

export function handleApiError(error: unknown) {
  if (error instanceof ApiError) {
    return Response.json(error.toJSON(), { status: error.statusCode });
  }

  console.error("Unhandled error:", error);

  return Response.json(
    {
      error: {
        code: "INTERNAL_ERROR",
        message: "An unexpected error occurred",
        details: [],
      },
    },
    { status: 500 }
  );
}
