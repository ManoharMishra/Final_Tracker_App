// examples/thread.usage.ts
//
// Example usage of the Thread Module APIs.
// These examples assume a running Next.js dev server at http://localhost:3000.

const BASE_URL = "http://localhost:3000/api";

// ─── Example 1: Create a Thread ─────────────────────────────────────────────

async function exampleCreateThread() {
  const response = await fetch(`${BASE_URL}/threads`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      title: "Q2 Product Roadmap Discussion",
      type: "team",
      goal: "Finalize Q2 priorities and assign ownership for each initiative",
      org_id: "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
      created_by: "u1a2b3c4-d5e6-7890-abcd-ef1234567890",
    }),
  });

  const result = await response.json();
  console.log("Created thread:", result.data);
  // result.data = {
  //   id: "...",
  //   title: "Q2 Product Roadmap Discussion",
  //   type: "team",
  //   status: "open",
  //   goal: "Finalize Q2 priorities and assign ownership for each initiative",
  //   org_id: "a1b2c3d4-...",
  //   created_by: "u1a2b3c4-...",
  //   last_activity_at: "2026-03-24T12:00:00.000Z",
  //   created_at: "2026-03-24T12:00:00.000Z",
  //   updated_at: "2026-03-24T12:00:00.000Z"
  // }
  //
  // Side effects (verified in DB):
  //  - thread_participants: { thread_id, user_id: created_by, role: "owner" }
  //  - thread_events: { event_type: "thread_created", payload: { entity_id, entity_type: "thread", data: { title, type } } }

  return result.data;
}

// ─── Example 2: Fetch Thread List ───────────────────────────────────────────

async function exampleListThreads(orgId: string, userId: string) {
  const params = new URLSearchParams({
    org_id: orgId,
    user_id: userId,
    status: "open",
    page: "1",
    limit: "10",
  });

  const response = await fetch(`${BASE_URL}/threads?${params}`);
  const result = await response.json();

  console.log(`Found ${result.pagination.total} threads:`);
  for (const thread of result.data) {
    console.log(
      `  [${thread.status}] ${thread.title} — ` +
      `${thread._count.participants} participants, ` +
      `${thread._count.messages} messages`
    );
  }
  // Output:
  //   Found 3 threads:
  //   [open] Q2 Product Roadmap Discussion — 4 participants, 12 messages
  //   [open] Bug Triage — 2 participants, 5 messages
  //   [open] Design Sprint Retro — 3 participants, 8 messages

  return result;
}

// ─── Example 3: Get Thread Detail ───────────────────────────────────────────

async function exampleGetThreadDetail(threadId: string) {
  const response = await fetch(`${BASE_URL}/threads/${threadId}`);
  const result = await response.json();

  const thread = result.data;
  console.log(`Thread: ${thread.title} (${thread.status})`);
  console.log(`Participants: ${thread._count.participants}`);
  console.log(`Messages: ${thread._count.messages}`);
  console.log(`Tasks: ${thread._count.tasks}`);
  console.log(`Decisions: ${thread._count.decisions}`);

  if (thread.latest_summary) {
    console.log(`Latest summary (v${thread.latest_summary.version}): ${thread.latest_summary.content.slice(0, 100)}...`);
  }

  // NOTE: Messages are NOT returned here.
  // Use GET /api/messages?thread_id=<id>&page=1&limit=20 for messages.

  return result.data;
}

// ─── Example 4: Update Thread Status ────────────────────────────────────────

async function exampleUpdateThread(threadId: string) {
  const response = await fetch(`${BASE_URL}/threads/${threadId}`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      status: "dormant",
      updated_by: "u1a2b3c4-d5e6-7890-abcd-ef1234567890",
    }),
  });

  const result = await response.json();
  console.log("Updated thread status:", result.data.status);
  // Side effect: thread_events record with event_type "thread_status_changed",
  // payload: { entity_id, entity_type: "thread", data: { from: "open", to: "dormant" } }

  return result.data;
}

// ─── Example 5: Soft Delete Thread ──────────────────────────────────────────

async function exampleDeleteThread(threadId: string) {
  const response = await fetch(`${BASE_URL}/threads/${threadId}`, {
    method: "DELETE",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      deleted_by: "u1a2b3c4-d5e6-7890-abcd-ef1234567890",
    }),
  });

  console.log("Delete response status:", response.status); // 204
  // Thread is soft-deleted (deleted_at set), NOT hard-deleted.
  // Subsequent GET /api/threads/:id will return 404.
}

// ─── Run examples ───────────────────────────────────────────────────────────

async function main() {
  const thread = await exampleCreateThread();
  await exampleListThreads(thread.org_id, thread.created_by);
  await exampleGetThreadDetail(thread.id);
  await exampleUpdateThread(thread.id);
  await exampleDeleteThread(thread.id);
}

main().catch(console.error);
