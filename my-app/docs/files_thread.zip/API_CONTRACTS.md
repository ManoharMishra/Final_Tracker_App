# Thread Module — API Contracts

> Generated from SYSTEM SPECIFICATION v1.1. All code MUST conform to these contracts.

---

## Conventions

| Convention     | Value                                    |
| -------------- | ---------------------------------------- |
| Base path      | `/api`                                   |
| Content-Type   | `application/json`                       |
| IDs            | UUID v4                                  |
| Timestamps     | ISO 8601                                 |
| Pagination     | `?page=1&limit=20` (default)             |
| Soft deletes   | `deleted_at` timestamp; excluded by default |
| Max page size  | 100                                      |

### Standard Error Response

```json
{
  "error": {
    "code": "VALIDATION_ERROR | NOT_FOUND | FORBIDDEN | CONFLICT | INTERNAL_ERROR",
    "message": "Human-readable message",
    "details": []
  }
}
```

### Standard List Response

```json
{
  "data": [...],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 142,
    "total_pages": 8
  }
}
```

---

## 1. POST /api/threads

**Create a thread.**

### Request Body

```typescript
{
  title: string;       // 3–200 chars, required
  type: "private" | "team" | "org";  // required
  goal?: string;       // max 500 chars, optional
  org_id: string;      // UUID, required
  created_by: string;  // UUID, required
}
```

### Response `201 Created`

```typescript
{
  data: {
    id: string;              // UUID
    title: string;
    type: "private" | "team" | "org";
    status: "open";          // always "open" on creation
    goal: string | null;
    org_id: string;
    created_by: string;
    last_activity_at: string; // ISO 8601
    created_at: string;
    updated_at: string;
  }
}
```

### Side Effects

1. Creates `ThreadParticipant` with `role = "owner"` for `created_by`.
2. Creates `ThreadEvent`:
   - `event_type`: `"thread_created"`
   - `payload`: `{ entity_id: thread.id, entity_type: "thread", data: { title, type } }`

---

## 2. GET /api/threads

**List threads with filters.**

### Query Parameters

| Param    | Type   | Required | Default | Constraints      |
| -------- | ------ | -------- | ------- | ---------------- |
| `org_id` | UUID   | YES      | —       | Multi-tenant key |
| `status` | string | no       | —       | open, dormant, converted |
| `type`   | string | no       | —       | private, team, org |
| `page`   | int    | no       | 1       | ≥ 1              |
| `limit`  | int    | no       | 20      | 1–100            |
| `user_id`| UUID   | YES      | —       | Participation filter |

### Response `200 OK`

```typescript
{
  data: Array<{
    id: string;
    title: string;
    type: "private" | "team" | "org";
    status: "open" | "dormant" | "converted";
    goal: string | null;
    org_id: string;
    created_by: string;
    last_activity_at: string;
    created_at: string;
    updated_at: string;
    _count: {
      participants: number;
      messages: number;
    }
  }>;
  pagination: {
    page: number;
    limit: number;
    total: number;
    total_pages: number;
  }
}
```

### Rules

- `org_id` is **mandatory** (SR-014).
- Only threads where `user_id` is a participant are returned (SR-006).
- Soft-deleted threads excluded (SR-003).
- Sorted by `last_activity_at DESC`.

---

## 3. GET /api/threads/:threadId

**Thread detail with context.**

### Response `200 OK`

```typescript
{
  data: {
    id: string;
    title: string;
    type: "private" | "team" | "org";
    status: "open" | "dormant" | "converted";
    goal: string | null;
    org_id: string;
    created_by: string;
    last_activity_at: string;
    created_at: string;
    updated_at: string;
    participants: Array<{
      id: string;
      user_id: string;
      role: "owner" | "member";
      last_read_at: string | null;
      user: { id: string; name: string; email: string; avatar_url: string | null; }
    }>;
    latest_summary: {
      id: string;
      content: string;
      version: number;
      created_by: string;
      created_at: string;
    } | null;
    recent_decisions: Array<{
      id: string;
      content: string;
      is_ai_generated: boolean;
      created_by: string;
      created_at: string;
    }>;  // limit 5
    _count: {
      messages: number;
      participants: number;
      tasks: number;
      decisions: number;
    }
  }
}
```

### Rules

- Messages are **NOT** returned (use `GET /api/messages?thread_id=`).
- Soft-deleted threads return `404`.

---

## 4. PATCH /api/threads/:threadId

**Update thread.**

### Request Body (all optional, at least one required)

```typescript
{
  title?: string;   // 3–200 chars
  goal?: string;    // max 500 chars
  status?: "open" | "dormant" | "converted";
}
```

### Response `200 OK`

```typescript
{
  data: {
    // ...full thread object (same shape as create response)
  }
}
```

### Side Effects

- If `status` changed → `ThreadEvent` with `event_type = "thread_status_changed"`, payload `{ entity_id, entity_type: "thread", data: { from, to } }`.
- If non-status fields changed → `ThreadEvent` with `event_type = "thread_updated"`, payload `{ entity_id, entity_type: "thread", data: { changed_fields } }`.
- `last_activity_at` updated (SR-001).

---

## 5. DELETE /api/threads/:threadId

**Soft delete.**

### Response `204 No Content`

### Rules

- Sets `deleted_at = now()`. Does **NOT** hard delete.
- Creates `ThreadEvent` with `event_type = "thread_updated"`, payload indicating soft delete.

---

## Event Payload Standard

All `thread_events.payload` MUST follow:

```typescript
{
  entity_id: string;      // UUID of affected entity
  entity_type: "thread" | "message" | "task" | "decision" | "summary" | "attachment";
  data: Record<string, any>;  // event-specific fields
}
```
