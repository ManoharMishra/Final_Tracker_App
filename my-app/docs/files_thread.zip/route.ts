// app/api/threads/route.ts

import { NextRequest } from "next/server";
import { handleApiError, ApiError } from "@/lib/errors";
import {
  createThreadSchema,
  listThreadsSchema,
} from "@/lib/validations/thread.validation";
import {
  createThread,
  getThreads,
} from "@/services/thread.service";

// ─── POST /api/threads ─────────────────────────────────────────────────────

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const parsed = createThreadSchema.safeParse(body);
    if (!parsed.success) {
      throw new ApiError(
        "VALIDATION_ERROR",
        "Invalid request body",
        parsed.error.issues
      );
    }

    const thread = await createThread(parsed.data);

    return Response.json({ data: thread }, { status: 201 });
  } catch (error) {
    return handleApiError(error);
  }
}

// ─── GET /api/threads ───────────────────────────────────────────────────────

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);

    const params = {
      org_id: searchParams.get("org_id") ?? "",
      user_id: searchParams.get("user_id") ?? "",
      status: searchParams.get("status") ?? undefined,
      type: searchParams.get("type") ?? undefined,
      page: searchParams.get("page") ?? "1",
      limit: searchParams.get("limit") ?? "20",
    };

    const parsed = listThreadsSchema.safeParse(params);
    if (!parsed.success) {
      throw new ApiError(
        "VALIDATION_ERROR",
        "Invalid query parameters",
        parsed.error.issues
      );
    }

    const result = await getThreads(parsed.data);

    return Response.json(result);
  } catch (error) {
    return handleApiError(error);
  }
}
