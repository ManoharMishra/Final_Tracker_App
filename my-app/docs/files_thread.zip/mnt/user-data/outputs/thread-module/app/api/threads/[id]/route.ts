// app/api/threads/[id]/route.ts

import { NextRequest } from "next/server";
import { handleApiError, ApiError } from "@/lib/errors";
import {
  threadIdParamSchema,
  updateThreadRequestSchema,
  deleteThreadRequestSchema,
} from "@/lib/validations/thread.validation";
import {
  getThreadById,
  updateThread,
  deleteThread,
} from "@/services/thread.service";

type RouteContext = { params: Promise<{ id: string }> };

// ─── GET /api/threads/:id ───────────────────────────────────────────────────

export async function GET(
  _request: NextRequest,
  context: RouteContext
) {
  try {
    const { id } = await context.params;

    const parsed = threadIdParamSchema.safeParse({ threadId: id });
    if (!parsed.success) {
      throw new ApiError(
        "VALIDATION_ERROR",
        "Invalid thread ID",
        parsed.error.issues
      );
    }

    const thread = await getThreadById(parsed.data.threadId);

    return Response.json({ data: thread });
  } catch (error) {
    return handleApiError(error);
  }
}

// ─── PATCH /api/threads/:id ─────────────────────────────────────────────────

export async function PATCH(
  request: NextRequest,
  context: RouteContext
) {
  try {
    const { id } = await context.params;

    const paramParsed = threadIdParamSchema.safeParse({ threadId: id });
    if (!paramParsed.success) {
      throw new ApiError(
        "VALIDATION_ERROR",
        "Invalid thread ID",
        paramParsed.error.issues
      );
    }

    const body = await request.json();
    const parsed = updateThreadRequestSchema.safeParse(body);
    if (!parsed.success) {
      throw new ApiError(
        "VALIDATION_ERROR",
        "Invalid request body",
        parsed.error.issues
      );
    }

    const updated = await updateThread(
      paramParsed.data.threadId,
      parsed.data
    );

    return Response.json({ data: updated });
  } catch (error) {
    return handleApiError(error);
  }
}

// ─── DELETE /api/threads/:id ────────────────────────────────────────────────

export async function DELETE(
  request: NextRequest,
  context: RouteContext
) {
  try {
    const { id } = await context.params;

    const paramParsed = threadIdParamSchema.safeParse({ threadId: id });
    if (!paramParsed.success) {
      throw new ApiError(
        "VALIDATION_ERROR",
        "Invalid thread ID",
        paramParsed.error.issues
      );
    }

    // In production, deleted_by would come from auth middleware (JWT).
    // Per spec v1.1 §7, current mode passes user_id in request body.
    const body = await request.json().catch(() => null);
    if (!body) {
      throw new ApiError(
        "VALIDATION_ERROR",
        "Request body with deleted_by is required"
      );
    }

    const parsed = deleteThreadRequestSchema.safeParse(body);
    if (!parsed.success) {
      throw new ApiError(
        "VALIDATION_ERROR",
        "deleted_by is required",
        parsed.error.issues
      );
    }
    const deletedBy = parsed.data.deleted_by;

    await deleteThread(paramParsed.data.threadId, deletedBy);

    return new Response(null, { status: 204 });
  } catch (error) {
    return handleApiError(error);
  }
}
