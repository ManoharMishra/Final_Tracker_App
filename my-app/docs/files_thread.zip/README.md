# Thread Module

Production-ready thread management module built with **Next.js App Router**, **Prisma ORM**, and **PostgreSQL**, strictly conforming to SYSTEM SPECIFICATION v1.1.

---

## File Structure

```
thread-module/
├── API_CONTRACTS.md                        # Contract-first: all endpoints defined before code
├── README.md                               # This file
├── prisma/
│   └── schema.prisma                       # Thread + related models, enums, indexes
├── lib/
│   ├── prisma.ts                           # Singleton PrismaClient
│   ├── errors.ts                           # ApiError class + handleApiError utility
│   ├── types/
│   │   └── thread.types.ts                 # Shared TypeScript types (derived from contracts)
│   └── validations/
│       └── thread.validation.ts            # Zod schemas for all inputs
├── services/
│   ├── thread.service.ts                   # Core business logic (5 functions)
│   └── threadEvent.service.ts              # Event creation helper (SR-002)
├── app/
│   └── api/
│       └── threads/
│           ├── route.ts                    # POST + GET /api/threads
│           └── [id]/
│               └── route.ts               # GET + PATCH + DELETE /api/threads/:id
└── examples/
    └── thread.usage.ts                     # Runnable examples for all 5 operations
```

---

## Setup

### 1. Install dependencies

```bash
npm install @prisma/client zod
npm install -D prisma
```

### 2. Configure database

```env
# .env
DATABASE_URL="postgresql://user:password@localhost:5432/collab_platform?schema=public"
```

### 3. Generate Prisma client & migrate

```bash
npx prisma generate
npx prisma migrate dev --name init
```

### 4. Run the dev server

```bash
npm run dev
```

---

## API Endpoints

| Method   | Endpoint              | Description         |
| -------- | --------------------- | ------------------- |
| `POST`   | `/api/threads`        | Create a thread     |
| `GET`    | `/api/threads`        | List threads        |
| `GET`    | `/api/threads/:id`    | Get thread detail   |
| `PATCH`  | `/api/threads/:id`    | Update thread       |
| `DELETE` | `/api/threads/:id`    | Soft delete thread  |

Full request/response contracts are in [`API_CONTRACTS.md`](./API_CONTRACTS.md).

---

## Architecture Decisions

### Contract-First
- `API_CONTRACTS.md` was written before any code
- Zod schemas in `thread.validation.ts` enforce contracts at runtime
- TypeScript types in `thread.types.ts` enforce contracts at compile time

### Service Layer Pattern
- Route handlers are thin: parse → validate → delegate to service → respond
- All business logic lives in `thread.service.ts`
- Event creation is a dedicated service (`threadEvent.service.ts`)

### Transactional Integrity
- All mutations use `prisma.$transaction()` to ensure atomicity
- Thread creation, participant creation, and event creation happen in one transaction
- Updates + event creation are also atomic

---

## System Rules Compliance Matrix

| Rule    | Description                              | Enforcement                                   |
| ------- | ---------------------------------------- | --------------------------------------------- |
| SR-001  | Update `last_activity_at` on actions     | `createThread`, `updateThread` set timestamp   |
| SR-002  | Every mutation creates `thread_event`    | `createThreadEventTx` called in every tx block |
| SR-003  | Soft deletes, filter `deleted_at IS NULL`| `NOT_DELETED` constant applied to all queries  |
| SR-006  | Creator must be participant (owner)      | `createThread` adds owner in same transaction  |
| SR-009  | Pagination defaults (page=1, limit=20)   | Zod defaults + max 100 enforced                |
| SR-013  | Empty thread handling                    | Queries return empty arrays, no errors         |
| SR-014  | All queries scoped by `org_id`           | `org_id` is required param on list endpoint    |

---

## What This Module Does NOT Include

Per the prompt requirements, this module is scoped to threads only:

- ❌ Messages API (separate module)
- ❌ Tasks API (separate module)
- ❌ Decisions API (separate module)
- ❌ Attachments API (separate module)
- ❌ Notifications (derived from events, separate module)
- ❌ Auth middleware (spec §7: user_id in request body for now)
