// examples/participant.usage.ts
//
// Example usage of the Thread Participants Module APIs.
// Assumes a running Next.js dev server at http://localhost:3000
// and an existing thread + users from the Thread Module examples.

const BASE_URL = "http://localhost:3000/api";

// ─── Setup: IDs from Thread Module ──────────────────────────────────────────

const THREAD_ID = "c1d2e3f4-a5b6-7890-abcd-ef1234567890";  // existing thread
const OWNER_ID  = "u1a2b3c4-d5e6-7890-abcd-ef1234567890";  // thread creator (owner)
const NEW_USER  = "u9f8e7d6-c5b4-3210-abcd-ef0987654321";  // user to add

// ─── Example 1: Add Participant ─────────────────────────────────────────────

async function exampleAddParticipant() {
  const response = await fetch(
    `${BASE_URL}/threads/${THREAD_ID}/participants`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        user_id: NEW_USER,
        role: "member",
        added_by: OWNER_ID,
      }),
    }
  );

  const result = await response.json();
  console.log("Added participant:", result.data);
  // result.data = {
  //   id: "...",
  //   thread_id: "c1d2e3f4-...",
  //   user_id: "u9f8e7d6-...",
  //   role: "member",
  //   last_read_at: null,
  //   created_at: "2026-03-24T...",
  //   updated_at: "2026-03-24T...",
  //   user: { id, name, email, avatar_url }
  // }
  //
  // Side effects verified in DB:
  //  - thread_events: { event_type: "participant_added", payload: { entity_id, entity_type: "thread", data: { user_id, role } } }
  //  - notifications: { user_id: NEW_USER, type: "thread_update", title: 'You were added to "..."' }

  return result.data;
}

// ─── Example 2: List Participants ───────────────────────────────────────────

async function exampleListParticipants() {
  const params = new URLSearchParams({ user_id: OWNER_ID });

  const response = await fetch(
    `${BASE_URL}/threads/${THREAD_ID}/participants?${params}`
  );

  const result = await response.json();
  console.log(`Thread has ${result.data.length} participants:`);
  for (const p of result.data) {
    console.log(`  [${p.role}] ${p.user.name} (${p.user.email})`);
  }
  // Output:
  //   Thread has 2 participants:
  //   [owner] Alice Johnson (alice@example.com)
  //   [member] Bob Smith (bob@example.com)

  return result.data;
}

// ─── Example 3: Update Last Read (unread tracking) ──────────────────────────

async function exampleUpdateLastRead() {
  const response = await fetch(
    `${BASE_URL}/threads/${THREAD_ID}/read`,
    {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ user_id: NEW_USER }),
    }
  );

  const result = await response.json();
  console.log("Updated last_read_at:", result.data.last_read_at);
  // result.data = {
  //   thread_id: "c1d2e3f4-...",
  //   user_id: "u9f8e7d6-...",
  //   last_read_at: "2026-03-24T14:30:00.000Z"
  // }
  //
  // No event or notification created — read-tracking is passive.

  return result.data;
}

// ─── Example 4: Remove Participant ──────────────────────────────────────────

async function exampleRemoveParticipant() {
  const response = await fetch(
    `${BASE_URL}/threads/${THREAD_ID}/participants/${NEW_USER}`,
    {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ removed_by: OWNER_ID }),
    }
  );

  console.log("Remove status:", response.status); // 204
  // Side effect:
  //  - thread_events: { event_type: "participant_removed", payload: { data: { user_id: NEW_USER } } }
}

// ─── Example 5: Error — Duplicate participant ───────────────────────────────

async function exampleDuplicateError() {
  // First add succeeds
  await fetch(`${BASE_URL}/threads/${THREAD_ID}/participants`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      user_id: NEW_USER,
      role: "member",
      added_by: OWNER_ID,
    }),
  });

  // Second add returns 409 CONFLICT
  const response = await fetch(
    `${BASE_URL}/threads/${THREAD_ID}/participants`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        user_id: NEW_USER,
        role: "member",
        added_by: OWNER_ID,
      }),
    }
  );

  const error = await response.json();
  console.log("Duplicate error:", response.status, error);
  // 409 { error: { code: "CONFLICT", message: "User ... is already a participant ...", details: [] } }
}

// ─── Example 6: Error — Remove last owner ───────────────────────────────────

async function exampleLastOwnerError() {
  const response = await fetch(
    `${BASE_URL}/threads/${THREAD_ID}/participants/${OWNER_ID}`,
    {
      method: "DELETE",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ removed_by: OWNER_ID }),
    }
  );

  const error = await response.json();
  console.log("Last owner error:", response.status, error);
  // 400 { error: { code: "VALIDATION_ERROR", message: "Cannot remove the last owner ...", details: [] } }
}

// ─── Run ────────────────────────────────────────────────────────────────────

async function main() {
  await exampleAddParticipant();
  await exampleListParticipants();
  await exampleUpdateLastRead();
  await exampleRemoveParticipant();
  await exampleDuplicateError();
  await exampleLastOwnerError();
}

main().catch(console.error);
