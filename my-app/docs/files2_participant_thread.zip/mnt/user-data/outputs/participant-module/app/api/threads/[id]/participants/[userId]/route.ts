// app/api/threads/[id]/participants/[userId]/route.ts

import { NextRequest } from "next/server";
import { handleApiError, ApiError } from "@/lib/errors";
import {
  participantParamsSchema,
  removeParticipantSchema,
} from "@/lib/validations/participant.validation";
import { removeParticipant } from "@/services/participant.service";

type RouteContext = { params: Promise<{ id: string; userId: string }> };

// ─── DELETE /api/threads/:threadId/participants/:userId ─────────────────────

export async function DELETE(request: NextRequest, context: RouteContext) {
  try {
    const { id, userId } = await context.params;

    const paramParsed = participantParamsSchema.safeParse({
      threadId: id,
      userId,
    });
    if (!paramParsed.success) {
      throw new ApiError(
        "VALIDATION_ERROR",
        "Invalid path parameters",
        paramParsed.error.issues
      );
    }

    const body = await request.json().catch(() => null);
    if (!body) {
      throw new ApiError(
        "VALIDATION_ERROR",
        "Request body with removed_by is required"
      );
    }

    const parsed = removeParticipantSchema.safeParse(body);
    if (!parsed.success) {
      throw new ApiError(
        "VALIDATION_ERROR",
        "Invalid request body",
        parsed.error.issues
      );
    }

    await removeParticipant(
      paramParsed.data.threadId,
      paramParsed.data.userId,
      parsed.data
    );

    return new Response(null, { status: 204 });
  } catch (error) {
    return handleApiError(error);
  }
}
