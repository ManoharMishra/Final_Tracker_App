// app/api/threads/[id]/read/route.ts

import { NextRequest } from "next/server";
import { handleApiError, ApiError } from "@/lib/errors";
import {
  threadIdParamSchema,
  updateLastReadSchema,
} from "@/lib/validations/participant.validation";
import { updateLastRead } from "@/services/participant.service";

type RouteContext = { params: Promise<{ id: string }> };

// ─── PATCH /api/threads/:threadId/read ──────────────────────────────────────

export async function PATCH(request: NextRequest, context: RouteContext) {
  try {
    const { id } = await context.params;

    const paramParsed = threadIdParamSchema.safeParse({ threadId: id });
    if (!paramParsed.success) {
      throw new ApiError(
        "VALIDATION_ERROR",
        "Invalid thread ID",
        paramParsed.error.issues
      );
    }

    const body = await request.json();
    const parsed = updateLastReadSchema.safeParse(body);
    if (!parsed.success) {
      throw new ApiError(
        "VALIDATION_ERROR",
        "Invalid request body",
        parsed.error.issues
      );
    }

    const result = await updateLastRead(
      paramParsed.data.threadId,
      parsed.data
    );

    return Response.json({ data: result });
  } catch (error) {
    return handleApiError(error);
  }
}
