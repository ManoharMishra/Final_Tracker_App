# Thread Participants Module — API Contracts

> Generated from SYSTEM SPECIFICATION v1.1. All code MUST conform to these contracts.
> This module integrates with the existing Thread Module (thread.service, threadEvent.service, errors, prisma).

---

## Conventions

Inherited from Thread Module — see Thread Module `API_CONTRACTS.md` for base conventions.

Additional for this module:

| Convention              | Value                                                         |
| ----------------------- | ------------------------------------------------------------- |
| Org scoping             | Thread's `org_id` must match the acting user's `org_id` (SR-014) |
| Participation gating    | Only existing participants can list participants (SR-006)      |
| Owner protection        | Last owner cannot be removed                                  |
| Notification derivation | `participant_added` event triggers notification (SR-007)      |

---

## 1. POST /api/threads/:threadId/participants

**Add a participant to a thread.**

### Path Parameters

| Param      | Type | Required | Constraints |
| ---------- | ---- | -------- | ----------- |
| `threadId` | UUID | YES      |             |

### Request Body

```typescript
{
  user_id: string;                    // UUID, required
  role?: "owner" | "member";          // default: "member"
  added_by: string;                   // UUID, required — the actor performing the action
}
```

### Response `201 Created`

```typescript
{
  data: {
    id: string;                       // participant record UUID
    thread_id: string;
    user_id: string;
    role: "owner" | "member";
    last_read_at: null;
    created_at: string;               // ISO 8601
    updated_at: string;
    user: {
      id: string;
      name: string;
      email: string;
      avatar_url: string | null;
    }
  }
}
```

### Error Responses

| Status | Code              | Condition                                |
| ------ | ----------------- | ---------------------------------------- |
| 400    | VALIDATION_ERROR  | Invalid UUID, missing fields             |
| 403    | FORBIDDEN         | Actor not in same org as thread          |
| 404    | NOT_FOUND         | Thread not found or soft-deleted / user not found |
| 409    | CONFLICT          | User is already a participant            |

### Side Effects

1. Creates `ThreadEvent`:
   - `event_type`: `"participant_added"`
   - `payload`: `{ entity_id: threadId, entity_type: "thread", data: { user_id, role } }`
2. Creates `Notification`:
   - `type`: `"thread_update"`
   - `user_id`: the added user (NOT the actor)
   - `title`: `You were added to "{thread.title}"`
   - `entity_type`: `"thread"`
   - `entity_id`: threadId

---

## 2. GET /api/threads/:threadId/participants

**List all participants in a thread.**

### Path Parameters

| Param      | Type | Required |
| ---------- | ---- | -------- |
| `threadId` | UUID | YES      |

### Query Parameters

| Param     | Type | Required | Notes                       |
| --------- | ---- | -------- | --------------------------- |
| `user_id` | UUID | YES      | Requesting user (for gating)|

### Response `200 OK`

```typescript
{
  data: Array<{
    id: string;
    thread_id: string;
    user_id: string;
    role: "owner" | "member";
    last_read_at: string | null;
    created_at: string;
    updated_at: string;
    user: {
      id: string;
      name: string;
      email: string;
      avatar_url: string | null;
    }
  }>
}
```

### Error Responses

| Status | Code       | Condition                         |
| ------ | ---------- | --------------------------------- |
| 403    | FORBIDDEN  | Requesting user is not a participant |
| 404    | NOT_FOUND  | Thread not found or soft-deleted  |

### Rules

- Thread must exist and `deleted_at IS NULL` (SR-003).
- Requesting user must be a participant in the thread (SR-006).

---

## 3. DELETE /api/threads/:threadId/participants/:userId

**Remove a participant from a thread.**

### Path Parameters

| Param      | Type | Required |
| ---------- | ---- | -------- |
| `threadId` | UUID | YES      |
| `userId`   | UUID | YES      | The user being removed |

### Request Body

```typescript
{
  removed_by: string;                 // UUID, required — the actor performing removal
}
```

### Response `204 No Content`

### Error Responses

| Status | Code              | Condition                              |
| ------ | ----------------- | -------------------------------------- |
| 400    | VALIDATION_ERROR  | Cannot remove last owner               |
| 403    | FORBIDDEN         | Actor is not an owner of the thread    |
| 404    | NOT_FOUND         | Thread or participant not found        |

### Side Effects

1. Creates `ThreadEvent`:
   - `event_type`: `"participant_removed"`
   - `payload`: `{ entity_id: threadId, entity_type: "thread", data: { user_id } }`

### Rules

- Only an owner can remove participants.
- If the target user is the last owner, removal is **blocked** (400).

---

## 4. PATCH /api/threads/:threadId/read

**Update the requesting user's last-read timestamp (unread tracking).**

### Path Parameters

| Param      | Type | Required |
| ---------- | ---- | -------- |
| `threadId` | UUID | YES      |

### Request Body

```typescript
{
  user_id: string;                    // UUID, required
}
```

### Response `200 OK`

```typescript
{
  data: {
    thread_id: string;
    user_id: string;
    last_read_at: string;             // ISO 8601 — the new timestamp
  }
}
```

### Error Responses

| Status | Code       | Condition                            |
| ------ | ---------- | ------------------------------------ |
| 404    | NOT_FOUND  | Thread not found or user not a participant |

### Rules

- Sets `last_read_at = now()`.
- No event or notification created (read-tracking is passive).
