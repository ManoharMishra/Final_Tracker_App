# Thread Participants Module

Production-ready participant management module for the Contextual Thread-Based Collaboration Platform. Built with **Next.js App Router**, **Prisma ORM**, and **PostgreSQL**, strictly conforming to SYSTEM SPECIFICATION v1.1.

Integrates with the existing **Thread Module** — reuses `createThreadEventTx`, `ApiError`, `handleApiError`, and the shared Prisma client.

---

## File Structure

```
participant-module/
├── API_CONTRACTS.md                                        # Contract-first definitions
├── README.md                                               # This file
├── prisma/
│   ├── schema.prisma                                       # Merged schema (Thread + Participant + Notification)
│   └── schema.participant.prisma                           # Diff / merge instructions for existing projects
├── lib/
│   ├── types/
│   │   └── participant.types.ts                            # Shared TypeScript response types
│   └── validations/
│       └── participant.validation.ts                       # Zod schemas for all inputs
├── services/
│   └── participant.service.ts                              # Core business logic (4 functions)
├── app/
│   └── api/
│       └── threads/
│           └── [id]/
│               ├── participants/
│               │   ├── route.ts                            # POST + GET  /api/threads/:id/participants
│               │   └── [userId]/
│               │       └── route.ts                        # DELETE      /api/threads/:id/participants/:userId
│               └── read/
│                   └── route.ts                            # PATCH       /api/threads/:id/read
└── examples/
    └── participant.usage.ts                                # Runnable examples for all operations
```

---

## Dependencies on Thread Module

This module imports from the Thread Module:

| Import                  | From                              | Purpose                           |
| ----------------------- | --------------------------------- | --------------------------------- |
| `prisma`                | `@/lib/prisma`                    | Database client singleton         |
| `ApiError`              | `@/lib/errors`                    | Structured error responses        |
| `handleApiError`        | `@/lib/errors`                    | Route-level error handling        |
| `createThreadEventTx`   | `@/services/threadEvent.service`  | Event creation inside transactions|

No circular dependencies. This module only adds new files — it does not modify any Thread Module files.

---

## Schema Changes Required

This module introduces the **Notification** model (required for SR-007: participant_added → notification).

Two new enums are added: `NotificationType` and `EntityType`.

See `prisma/schema.participant.prisma` for merge instructions, or use the provided `prisma/schema.prisma` which is the complete merged schema.

After merging:

```bash
npx prisma migrate dev --name add_notifications_and_participant_module
npx prisma generate
```

---

## API Endpoints

| Method   | Endpoint                                         | Description              |
| -------- | ------------------------------------------------ | ------------------------ |
| `POST`   | `/api/threads/:threadId/participants`            | Add participant          |
| `GET`    | `/api/threads/:threadId/participants`            | List participants        |
| `DELETE` | `/api/threads/:threadId/participants/:userId`    | Remove participant       |
| `PATCH`  | `/api/threads/:threadId/read`                    | Update last-read marker  |

Full request/response contracts are in [`API_CONTRACTS.md`](./API_CONTRACTS.md).

---

## Business Rules Enforced

### Add Participant
- Thread must exist and not be soft-deleted (SR-003)
- Target user and actor must belong to the same org as the thread (SR-014)
- Duplicate check via UNIQUE(thread_id, user_id) — returns 409 CONFLICT
- Creates ThreadEvent `participant_added` (SR-002)
- Creates Notification `thread_update` for the added user (SR-007)
- Notification is NOT created if user adds themselves

### List Participants
- Thread must exist and not be soft-deleted (SR-003)
- Requesting user must already be a participant (SR-006)
- Returns user details: id, name, email, avatar_url
- Ordered: owners first, then by join date

### Remove Participant
- Thread must exist and not be soft-deleted (SR-003)
- Only owners can remove participants (FORBIDDEN if not owner)
- Cannot remove the last owner (VALIDATION_ERROR)
- Creates ThreadEvent `participant_removed` (SR-002)

### Update Last Read
- Thread must exist and not be soft-deleted (SR-003)
- User must be a participant (NOT_FOUND otherwise)
- Sets `last_read_at = now()` — used for unread badge tracking
- No event or notification (read-tracking is passive)

---

## System Rules Compliance Matrix

| Rule    | Description                                | Enforcement                                          |
| ------- | ------------------------------------------ | ---------------------------------------------------- |
| SR-002  | Every mutation creates `thread_event`      | `createThreadEventTx` called in add + remove         |
| SR-003  | Soft deletes, filter `deleted_at IS NULL`  | `getActiveThread()` helper on every operation        |
| SR-006  | Participant gating                         | List requires participation; add enforces UNIQUE     |
| SR-007  | Notifications derived from events          | Notification created inside same tx as event         |
| SR-014  | Org scoping / multi-tenant isolation       | `validateUserInOrg()` checks org match for both actor and target |

---

## What This Module Does NOT Include

| Excluded                          | Reason                                |
| --------------------------------- | ------------------------------------- |
| Auth middleware                   | Spec §7: user_id passed in body       |
| Role change (member ↔ owner)     | Not in spec; add via PATCH if needed  |
| Notification read/list APIs      | Separate Notifications module         |
| Message/Task/Decision APIs       | Separate modules                      |
