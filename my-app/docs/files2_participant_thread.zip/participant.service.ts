// services/participant.service.ts

import { prisma } from "@/lib/prisma";
import { ApiError } from "@/lib/errors";
import { createThreadEventTx } from "@/services/threadEvent.service";
import type { Prisma } from "@prisma/client";
import type {
  AddParticipantInput,
  GetParticipantsQuery,
  RemoveParticipantInput,
  UpdateLastReadInput,
} from "@/lib/validations/participant.validation";

// ─── Shared filters ─────────────────────────────────────────────────────────

/** SR-003: All queries MUST exclude soft-deleted records */
const NOT_DELETED = { deleted_at: null } as const;

/** Reusable user select shape for participant responses */
const USER_SELECT = {
  id: true,
  name: true,
  email: true,
  avatar_url: true,
  org_id: true,
} as const;

// ─── Internal helpers ───────────────────────────────────────────────────────

/**
 * Loads and validates that a thread exists and is not soft-deleted.
 * Returns the thread if found, throws NOT_FOUND otherwise.
 */
async function getActiveThread(threadId: string, tx?: Prisma.TransactionClient) {
  const db = tx ?? prisma;
  const thread = await db.thread.findFirst({
    where: { id: threadId, ...NOT_DELETED },
    select: { id: true, title: true, org_id: true },
  });

  if (!thread) {
    throw new ApiError("NOT_FOUND", `Thread ${threadId} not found`);
  }

  return thread;
}

/**
 * Validates that a user exists and belongs to the same org as the thread.
 * SR-014: multi-tenant isolation.
 */
async function validateUserInOrg(
  userId: string,
  orgId: string,
  label: string,
  tx?: Prisma.TransactionClient
) {
  const db = tx ?? prisma;
  const user = await db.user.findUnique({
    where: { id: userId },
    select: { id: true, org_id: true },
  });

  if (!user) {
    throw new ApiError("NOT_FOUND", `User ${userId} not found`);
  }

  if (user.org_id !== orgId) {
    throw new ApiError(
      "FORBIDDEN",
      `${label} does not belong to the same organization as the thread`
    );
  }

  return user;
}

// ─── 1. Add Participant ─────────────────────────────────────────────────────

export async function addParticipant(
  threadId: string,
  input: AddParticipantInput
) {
  return prisma.$transaction(async (tx) => {
    // 1. Thread must exist and not be deleted (SR-003)
    const thread = await getActiveThread(threadId, tx);

    // 2. Validate the user being added belongs to the same org (SR-014)
    await validateUserInOrg(input.user_id, thread.org_id, "Target user", tx);

    // 3. Validate the actor belongs to the same org (SR-014)
    await validateUserInOrg(input.added_by, thread.org_id, "Actor", tx);

    // 4. Check for duplicate — UNIQUE(thread_id, user_id) constraint
    const existing = await tx.threadParticipant.findUnique({
      where: {
        thread_id_user_id: {
          thread_id: threadId,
          user_id: input.user_id,
        },
      },
    });

    if (existing) {
      throw new ApiError(
        "CONFLICT",
        `User ${input.user_id} is already a participant in this thread`
      );
    }

    // 5. Create participant
    const participant = await tx.threadParticipant.create({
      data: {
        thread_id: threadId,
        user_id: input.user_id,
        role: input.role,
      },
      include: {
        user: { select: USER_SELECT },
      },
    });

    // 6. SR-002: create thread_event
    await createThreadEventTx(tx, {
      threadId,
      eventType: "participant_added",
      actorId: input.added_by,
      payload: {
        entity_id: threadId,
        entity_type: "thread",
        data: {
          user_id: input.user_id,
          role: input.role,
        },
      },
    });

    // 7. SR-007: Create notification for the added user (not the actor)
    //    Notification type: "thread_update", derived from the event.
    if (input.user_id !== input.added_by) {
      await tx.notification.create({
        data: {
          user_id: input.user_id,
          org_id: thread.org_id,
          type: "thread_update",
          title: `You were added to "${thread.title}"`,
          entity_type: "thread",
          entity_id: threadId,
        },
      });
    }

    // Strip org_id from the user object in response (not part of contract)
    const { org_id: _orgId, ...userWithoutOrg } = participant.user;

    return {
      ...participant,
      user: userWithoutOrg,
    };
  });
}

// ─── 2. Get Participants ────────────────────────────────────────────────────

export async function getParticipants(
  threadId: string,
  query: GetParticipantsQuery
) {
  // 1. Thread must exist and not be deleted (SR-003)
  const thread = await getActiveThread(threadId);

  // 2. SR-006: requesting user must be a participant
  const requestingParticipant = await prisma.threadParticipant.findUnique({
    where: {
      thread_id_user_id: {
        thread_id: threadId,
        user_id: query.user_id,
      },
    },
  });

  if (!requestingParticipant) {
    throw new ApiError(
      "FORBIDDEN",
      "You must be a participant in this thread to view participants"
    );
  }

  // 3. Fetch all participants with user details
  const participants = await prisma.threadParticipant.findMany({
    where: { thread_id: threadId },
    include: {
      user: {
        select: {
          id: true,
          name: true,
          email: true,
          avatar_url: true,
        },
      },
    },
    orderBy: [
      { role: "asc" },       // owners first
      { created_at: "asc" }, // then by join order
    ],
  });

  return participants;
}

// ─── 3. Remove Participant ──────────────────────────────────────────────────

export async function removeParticipant(
  threadId: string,
  targetUserId: string,
  input: RemoveParticipantInput
) {
  return prisma.$transaction(async (tx) => {
    // 1. Thread must exist and not be deleted (SR-003)
    await getActiveThread(threadId, tx);

    // 2. Only an owner can remove participants
    const actorParticipant = await tx.threadParticipant.findUnique({
      where: {
        thread_id_user_id: {
          thread_id: threadId,
          user_id: input.removed_by,
        },
      },
    });

    if (!actorParticipant || actorParticipant.role !== "owner") {
      throw new ApiError(
        "FORBIDDEN",
        "Only thread owners can remove participants"
      );
    }

    // 3. Target participant must exist
    const targetParticipant = await tx.threadParticipant.findUnique({
      where: {
        thread_id_user_id: {
          thread_id: threadId,
          user_id: targetUserId,
        },
      },
    });

    if (!targetParticipant) {
      throw new ApiError(
        "NOT_FOUND",
        `User ${targetUserId} is not a participant in this thread`
      );
    }

    // 4. Cannot remove the last owner
    if (targetParticipant.role === "owner") {
      const ownerCount = await tx.threadParticipant.count({
        where: {
          thread_id: threadId,
          role: "owner",
        },
      });

      if (ownerCount <= 1) {
        throw new ApiError(
          "VALIDATION_ERROR",
          "Cannot remove the last owner of a thread. Transfer ownership first."
        );
      }
    }

    // 5. Delete participant
    await tx.threadParticipant.delete({
      where: { id: targetParticipant.id },
    });

    // 6. SR-002: create thread_event
    await createThreadEventTx(tx, {
      threadId,
      eventType: "participant_removed",
      actorId: input.removed_by,
      payload: {
        entity_id: threadId,
        entity_type: "thread",
        data: { user_id: targetUserId },
      },
    });
  });
}

// ─── 4. Update Last Read ────────────────────────────────────────────────────

export async function updateLastRead(
  threadId: string,
  input: UpdateLastReadInput
) {
  // 1. Thread must exist and not be deleted (SR-003)
  await getActiveThread(threadId);

  // 2. User must be a participant
  const participant = await prisma.threadParticipant.findUnique({
    where: {
      thread_id_user_id: {
        thread_id: threadId,
        user_id: input.user_id,
      },
    },
  });

  if (!participant) {
    throw new ApiError(
      "NOT_FOUND",
      "User is not a participant in this thread"
    );
  }

  // 3. Update last_read_at (no event — read-tracking is passive)
  const now = new Date();

  const updated = await prisma.threadParticipant.update({
    where: { id: participant.id },
    data: { last_read_at: now },
    select: {
      thread_id: true,
      user_id: true,
      last_read_at: true,
    },
  });

  return updated;
}
